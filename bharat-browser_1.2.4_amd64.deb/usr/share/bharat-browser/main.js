// Bharat Browser v1.2.4 initialization script
console.log("Bharat Browser v1.2.4 initialized.");
