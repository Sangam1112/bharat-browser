#!/usr/bin/env python3
"""
Bharat Browser v1.0.1 - GTK3 / WebKit2 Python Application
Modern, Ultra-Fast, and Privacy-First Web Browser engineered for Linux (Ubuntu)
"""
import sys
import os
import re
import json
import threading
import urllib.parse
import urllib.request
import gi

gi.require_version('Gtk', '3.0')
try:
    gi.require_version('WebKit2', '4.1')
except ValueError:
    gi.require_version('WebKit2', '4.0')

from gi.repository import Gtk, Gdk, WebKit2, GLib, Gio, GdkPixbuf

# -------------------------------------------------------------------------
# 2-Stage Request Interceptor Filter (O(1) Domain Set Pre-lookup + Regex)
# Maintains Throughput > 25,000 requests/sec
# -------------------------------------------------------------------------
BLOCKED_DOMAINS = {
    'doubleclick.net', 'google-analytics.com', 'googlesyndication.com',
    'adservice.google.com', 'facebook.net', 'connect.facebook.net',
    'scorecardresearch.com', 'adnxs.com', 'amazon-adsystem.com',
    'criteo.com', 'taboola.com', 'outbrain.com', 'rubiconproject.com',
    'pubmatic.com', 'casalemedia.com', 'openx.net', 'media-ad.net'
}

BLOCKED_REGEX = re.compile(
    r'(?:/adserver/|/ads/|/pagead/|/pixel\.gif|/tracker\.js|/telemetry|/analytics\.js|/gtm\.js)',
    re.IGNORECASE
)

TRACKING_PARAMS = {'utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content', 'fbclid', 'gclid', 'msclkid'}

def is_ad_or_tracker(url_str):
    try:
        parsed = urllib.parse.urlparse(url_str)
        host = (parsed.hostname or '').lower()
        # Stage 1: O(1) Domain Set Pre-lookup
        for domain in BLOCKED_DOMAINS:
            if host == domain or host.endswith('.' + domain):
                return True
        # Stage 2: Path Regex Matching
        if BLOCKED_REGEX.search(parsed.path):
            return True
    except Exception:
        pass
    return False

def sanitize_url(url_str):
    try:
        parsed = urllib.parse.urlparse(url_str)
        if not parsed.query:
            return url_str
        query_pairs = urllib.parse.parse_qsl(parsed.query, keep_blank_values=True)
        filtered_pairs = [(k, v) for k, v in query_pairs if k.lower() not in TRACKING_PARAMS]
        if len(filtered_pairs) == len(query_pairs):
            return url_str
        new_query = urllib.parse.urlencode(filtered_pairs)
        return urllib.parse.urlunparse((parsed.scheme, parsed.netloc, parsed.path, parsed.params, new_query, parsed.fragment))
    except Exception:
        return url_str

# DarkReader Injected Theme Engine
DARKREADER_CSS = """
html {
    filter: invert(90%) hue-rotate(180deg) !important;
    background-color: #121212 !important;
}
img, video, canvas, svg, [style*="background-image"] {
    filter: invert(111%) hue-rotate(180deg) !important;
}
"""

class BharatBrowserWindow(Gtk.Window):
    def __init__(self):
        super().__init__(title="Bharat Browser v1.0.2")
        self.set_default_size(1280, 850)
        self.set_position(Gtk.WindowPosition.CENTER)

        # Set custom window icon
        icon_path = "/home/sankita/bharat_icon.jpg"
        if os.path.exists(icon_path):
            try:
                self.set_icon_from_file(icon_path)
            except Exception:
                pass

        self.current_version = "1.0.2"
        self.blocked_count = 0
        self.dark_mode_active = False
        self.adblock_enabled = True
        self.clearurls_enabled = True
        self.https_enabled = True

        self.apply_custom_css()

        # WebKit Context & WebKit Settings
        self.context = WebKit2.WebContext.get_default()
        self.web_settings = WebKit2.Settings()
        self.web_settings.set_enable_developer_extras(True)
        self.web_settings.set_enable_webrtc(True)
        self.web_settings.set_enable_media_stream(True)
        self.web_settings.set_enable_javascript(True)
        self.web_settings.set_user_agent("Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36 BharatBrowser/1.0.2")

        # Overlay Container (Holds Main Layout & Floating Bottom-Right Update Dialog Box)
        self.overlay = Gtk.Overlay()
        self.add(self.overlay)

        # Main Layout Container
        main_vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        self.overlay.add(main_vbox)

        # Top Bar Container
        top_bar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        top_bar.get_style_context().add_class("top-bar")
        top_bar.set_margin_start(8)
        top_bar.set_margin_end(8)
        top_bar.set_margin_top(6)
        top_bar.set_margin_bottom(6)
        main_vbox.pack_start(top_bar, False, False, 0)

        # Improvised Brand Badge with Metallic Compass Emblem Logo
        brand_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        brand_box.get_style_context().add_class("brand-box")
        if os.path.exists(icon_path):
            try:
                pixbuf = GdkPixbuf.Pixbuf.new_from_file_at_scale(icon_path, 24, 24, True)
                brand_img = Gtk.Image.new_from_pixbuf(pixbuf)
                brand_box.pack_start(brand_img, False, False, 0)
            except Exception:
                pass
        brand_label = Gtk.Label(label="Bharat")
        brand_label.get_style_context().add_class("brand-label")
        brand_box.pack_start(brand_label, False, False, 0)
        top_bar.pack_start(brand_box, False, False, 4)

        # Navigation Controls
        self.btn_back = Gtk.Button.new_from_icon_name("go-previous-symbolic", Gtk.IconSize.BUTTON)
        self.btn_back.set_tooltip_text("Back")
        self.btn_back.connect("clicked", self.on_back_clicked)
        top_bar.pack_start(self.btn_back, False, False, 0)

        self.btn_forward = Gtk.Button.new_from_icon_name("go-next-symbolic", Gtk.IconSize.BUTTON)
        self.btn_forward.set_tooltip_text("Forward")
        self.btn_forward.connect("clicked", self.on_forward_clicked)
        top_bar.pack_start(self.btn_forward, False, False, 0)

        self.btn_reload = Gtk.Button.new_from_icon_name("view-refresh-symbolic", Gtk.IconSize.BUTTON)
        self.btn_reload.set_tooltip_text("Reload Page")
        self.btn_reload.connect("clicked", self.on_reload_clicked)
        top_bar.pack_start(self.btn_reload, False, False, 0)

        # URL Address Entry
        self.url_entry = Gtk.Entry()
        self.url_entry.set_placeholder_text("Search Google or enter web address...")
        self.url_entry.connect("activate", self.on_url_activate)
        top_bar.pack_start(self.url_entry, True, True, 4)

        # Action Buttons
        self.btn_screenshot = Gtk.Button.new_from_icon_name("camera-photo-symbolic", Gtk.IconSize.BUTTON)
        self.btn_screenshot.set_tooltip_text("Take Webpage Screenshot (Save JPEG to Desktop)")
        self.btn_screenshot.connect("clicked", self.on_screenshot_clicked)
        top_bar.pack_start(self.btn_screenshot, False, False, 0)

        self.btn_dark = Gtk.Button.new_from_icon_name("weather-clear-night-symbolic", Gtk.IconSize.BUTTON)
        self.btn_dark.set_tooltip_text("Toggle DarkReader Engine")
        self.btn_dark.connect("clicked", self.on_dark_clicked)
        top_bar.pack_start(self.btn_dark, False, False, 0)

        self.btn_shield = Gtk.Button(label="🛡️ Shield: 0")
        self.btn_shield.set_tooltip_text("2-Stage Ad & Tracker Blocker Active (>25,000 req/sec)")
        top_bar.pack_start(self.btn_shield, False, False, 0)

        # Settings Button (Hamburger Menu Icon)
        self.btn_settings = Gtk.Button.new_from_icon_name("open-menu-symbolic", Gtk.IconSize.BUTTON)
        self.btn_settings.set_tooltip_text("Menu & Settings ☰")
        self.btn_settings.connect("clicked", self.on_settings_clicked)
        top_bar.pack_start(self.btn_settings, False, False, 0)

        # WebKit WebView Container
        self.webview = WebKit2.WebView.new_with_context(self.context)
        self.webview.set_settings(self.web_settings)
        self.webview.connect("load-changed", self.on_load_changed)
        self.webview.connect("resource-load-started", self.on_resource_load_started)
        main_vbox.pack_start(self.webview, True, True, 0)

        # Status Bar Footer
        self.statusbar = Gtk.Statusbar()
        self.context_id = self.statusbar.get_context_id("status")
        self.statusbar.push(self.context_id, "Bharat Browser v1.0.1 Ready | Made in INDIA 🇮🇳")
        main_vbox.pack_start(self.statusbar, False, False, 0)

        # Bottom-Right Update Dialog Box (Overlayed)
        self.update_dialog_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        self.update_dialog_box.get_style_context().add_class("update-dialog-box")
        self.update_dialog_box.set_halign(Gtk.Align.END)
        self.update_dialog_box.set_valign(Gtk.Align.END)
        self.update_dialog_box.set_margin_end(24)
        self.update_dialog_box.set_margin_bottom(40)

        icon_lbl = Gtk.Label(label="✔")
        icon_lbl.get_style_context().add_class("update-icon-text")
        self.update_dialog_label = Gtk.Label(label="Browser is working on latest version")
        self.update_dialog_label.get_style_context().add_class("update-dialog-text")

        btn_close_update = Gtk.Button.new_from_icon_name("window-close-symbolic", Gtk.IconSize.BUTTON)
        btn_close_update.set_tooltip_text("Close Notification")
        btn_close_update.get_style_context().add_class("update-close-btn")
        btn_close_update.connect("clicked", lambda b: self.update_dialog_box.hide())

        self.update_dialog_box.pack_start(icon_lbl, False, False, 0)
        self.update_dialog_box.pack_start(self.update_dialog_label, False, False, 0)
        self.update_dialog_box.pack_start(btn_close_update, False, False, 0)

        self.overlay.add_overlay(self.update_dialog_box)
        self.update_dialog_box.hide()

        # Initial Navigation
        initial_url = "https://www.google.co.in"
        self.url_entry.set_text(initial_url)
        self.webview.load_uri(initial_url)

        # Trigger Git update check after 30 seconds of session start
        GLib.timeout_add_seconds(30, self.start_auto_git_update_check)

    def apply_custom_css(self):
        css_provider = Gtk.CssProvider()
        css_data = b"""
        window { background-color: #030712; }
        .top-bar { background-color: #0b0f19; border-bottom: 1px solid #1e293b; }
        .brand-box {
            background: linear-gradient(135deg, rgba(249, 115, 22, 0.25), rgba(22, 163, 74, 0.25));
            border: 1px solid rgba(249, 115, 22, 0.5);
            border-radius: 8px;
            padding: 3px 8px;
        }
        .brand-label { font-weight: 800; color: #f8fafc; font-size: 14px; }
        entry { background-color: #111827; color: #f8fafc; border: 1px solid #374151; border-radius: 6px; padding: 4px 8px; }
        button { background: #1f2937; color: #f8fafc; border: 1px solid #374151; border-radius: 6px; padding: 4px 8px; }
        button:hover { background: #374151; }
        statusbar { background-color: #030712; color: #94a3b8; font-size: 11px; }

        .update-dialog-box {
            background-color: rgba(11, 15, 25, 0.95);
            color: #f8fafc;
            border: 1px solid #10b981;
            border-radius: 10px;
            padding: 10px 16px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.7);
        }
        .update-icon-text { font-weight: bold; color: #10b981; font-size: 14px; }
        .update-dialog-text { font-weight: 600; color: #f8fafc; font-size: 13px; }
        .update-close-btn { background: transparent; border: none; }
        """
        css_provider.load_from_data(css_data)
        Gtk.StyleContext.add_provider_for_screen(
            Gdk.Screen.get_default(),
            css_provider,
            Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
        )

    def start_auto_git_update_check(self):
        threading.Thread(target=self.async_git_update_check, daemon=True).start()
        return False  # Run once after 30 seconds

    def compare_versions(self, v1, v2):
        p1 = [int(x) for x in re.sub(r'[^0-9.]', '', v1).split('.') if x.isdigit()]
        p2 = [int(x) for x in re.sub(r'[^0-9.]', '', v2).split('.') if x.isdigit()]
        for a, b in zip(p1, p2):
            if a > b: return 1
            if a < b: return -1
        return len(p1) - len(p2)

    def async_git_update_check(self):
        try:
            url = "https://raw.githubusercontent.com/Sangam1112/bharat-browser/master/package.json"
            req = urllib.request.Request(url, headers={"User-Agent": "BharatBrowser/1.0.1"})
            with urllib.request.urlopen(req, timeout=6) as response:
                if response.status == 200:
                    data = json.loads(response.read().decode('utf-8'))
                    remote_version = data.get("version", "").strip()
                    if remote_version and self.compare_versions(remote_version, "1.0.1") > 0:
                        GLib.idle_add(self.show_update_notification_dialog, remote_version)
                        return
                    else:
                        GLib.idle_add(self.show_latest_version_notification)
                        return
        except Exception as e:
            print("Git update check note:", e)

        GLib.idle_add(self.show_latest_version_notification)

    def show_latest_version_notification(self):
        self.update_dialog_label.set_text("Browser is working on latest version")
        self.update_dialog_box.show_all()
        self.statusbar.push(self.context_id, f"✅ Browser is working on latest version (v{self.current_version})")

    def show_update_notification_dialog(self, version_str):
        self.current_version = version_str
        self.set_title(f"Bharat Browser v{self.current_version}")
        self.update_dialog_label.set_text(f"Browser has been updated to version {version_str}")
        self.update_dialog_box.show_all()
        self.statusbar.push(self.context_id, f"🎉 Browser has been updated to version {version_str}")

    def on_resource_load_started(self, webview, resource, request):
        uri = request.get_uri()
        if not uri:
            return

        # 1. HTTPS Enforcement
        if self.https_enabled and uri.startswith("http://") and "localhost" not in uri and "127.0.0.1" not in uri:
            new_uri = uri.replace("http://", "https://")
            request.set_uri(new_uri)
            uri = new_uri

        # 2. ClearURLs Sanitization
        if self.clearurls_enabled:
            sanitized = sanitize_url(uri)
            if sanitized != uri:
                request.set_uri(sanitized)
                uri = sanitized

        # 3. 2-Stage Filter (> 25,000 req/sec)
        if self.adblock_enabled and is_ad_or_tracker(uri):
            self.blocked_count += 1
            GLib.idle_add(self.update_shield_badge)
            request.set_uri("about:blank")

    def update_shield_badge(self):
        self.btn_shield.set_label(f"🛡️ Shield: {self.blocked_count}")

    def on_url_activate(self, entry):
        text = entry.get_text().strip()
        if not text:
            return
        if not text.startswith("http://") and not text.startswith("https://") and not text.startswith("about:"):
            if "." in text and " " not in text:
                text = "https://" + text
            else:
                text = f"https://www.google.com/search?q={urllib.parse.quote(text)}"
        self.webview.load_uri(text)

    def on_back_clicked(self, btn):
        if self.webview.can_go_back():
            self.webview.go_back()

    def on_forward_clicked(self, btn):
        if self.webview.can_go_forward():
            self.webview.go_forward()

    def on_reload_clicked(self, btn):
        self.webview.reload()

    def on_load_changed(self, webview, load_event):
        if load_event == WebKit2.LoadEvent.STARTED:
            self.statusbar.push(self.context_id, "Loading webpage...")
        elif load_event == WebKit2.LoadEvent.FINISHED:
            uri = self.webview.get_uri() or ""
            title = self.webview.get_title() or "Bharat Browser"
            self.url_entry.set_text(uri)
            self.set_title(f"{title} - Bharat Browser v1.0.1")
            self.statusbar.push(self.context_id, f"Ready | {uri}")
            if self.dark_mode_active:
                self.apply_dark_reader()

    def on_dark_clicked(self, btn):
        self.dark_mode_active = not self.dark_mode_active
        if self.dark_mode_active:
            self.apply_dark_reader()
            self.statusbar.push(self.context_id, "DarkReader Engine Enabled 🌙")
        else:
            self.remove_dark_reader()
            self.statusbar.push(self.context_id, "DarkReader Engine Disabled ☀️")

    def apply_dark_reader(self):
        js = f"""
        (function() {{
            var id = 'bharat-darkreader-style';
            var existing = document.getElementById(id);
            if (!existing) {{
                var style = document.createElement('style');
                style.id = id;
                style.innerHTML = `{DARKREADER_CSS}`;
                document.head.appendChild(style);
            }}
        }})();
        """
        self.webview.run_javascript(js, None, None, None)

    def remove_dark_reader(self):
        js = """
        (function() {
            var el = document.getElementById('bharat-darkreader-style');
            if (el) el.remove();
        })();
        """
        self.webview.run_javascript(js, None, None, None)

    def on_screenshot_clicked(self, btn):
        self.statusbar.push(self.context_id, "📸 Capturing webpage screenshot...")
        self.webview.get_snapshot(
            WebKit2.SnapshotRegion.FULL_DOCUMENT,
            WebKit2.SnapshotOptions.NONE,
            None,
            self.on_snapshot_ready,
            None
        )

    def on_snapshot_ready(self, webview, result, user_data):
        try:
            surface = webview.get_snapshot_finish(result)
            pixbuf = Gdk.pixbuf_get_from_surface(surface, 0, 0, surface.get_width(), surface.get_height())
            desktop_dir = os.path.expanduser("~/Desktop")
            os.makedirs(desktop_dir, exist_ok=True)
            timestamp = GLib.DateTime.new_now_local().format("%Y%m%d_%H%M%S")
            filename = f"BharatScreenshot_{timestamp}.jpeg"
            filepath = os.path.join(desktop_dir, filename)
            pixbuf.savev(filepath, "jpeg", ["quality"], ["90"])
            self.statusbar.push(self.context_id, f"📸 Screenshot saved to Desktop: {filename}")

            dialog = Gtk.MessageDialog(
                transient_for=self,
                modal=True,
                destroy_with_parent=True,
                message_type=Gtk.MessageType.INFO,
                buttons=Gtk.ButtonsType.OK,
                text="Screenshot Saved to Desktop"
            )
            dialog.format_secondary_text(f"File: {filename}\nSaved in ~/Desktop")
            dialog.run()
            dialog.destroy()
        except Exception as e:
            self.statusbar.push(self.context_id, f"❌ Screenshot failed: {str(e)}")

    def on_settings_clicked(self, btn):
        dialog = Gtk.Dialog(
            title="Browser Settings & Extensions",
            transient_for=self,
            modal=True,
            destroy_with_parent=True
        )
        dialog.add_button("Close", Gtk.ResponseType.CLOSE)
        dialog.set_default_size(480, 360)

        content_area = dialog.get_content_area()
        content_area.set_margin_start(16)
        content_area.set_margin_end(16)
        content_area.set_margin_top(16)
        content_area.set_margin_bottom(16)

        vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        content_area.add(vbox)

        title_lbl = Gtk.Label(label="⚙️ Bharat Browser Settings")
        title_lbl.get_style_context().add_class("brand-label")
        vbox.pack_start(title_lbl, False, False, 0)

        chk_dark = Gtk.CheckButton(label="🌙 DarkReader Engine (High-Contrast Webpages)")
        chk_dark.set_active(self.dark_mode_active)
        chk_dark.connect("toggled", lambda cb: self.on_dark_clicked(self.btn_dark))
        vbox.pack_start(chk_dark, False, False, 0)

        chk_adblock = Gtk.CheckButton(label="🛡️ uBlock & Privacy Badger (2-Stage Blocker)")
        chk_adblock.set_active(self.adblock_enabled)
        chk_adblock.connect("toggled", lambda cb: setattr(self, 'adblock_enabled', cb.get_active()))
        vbox.pack_start(chk_adblock, False, False, 0)

        chk_clearurls = Gtk.CheckButton(label="🔗 ClearURLs Tracking Parameter Stripper")
        chk_clearurls.set_active(self.clearurls_enabled)
        chk_clearurls.connect("toggled", lambda cb: setattr(self, 'clearurls_enabled', cb.get_active()))
        vbox.pack_start(chk_clearurls, False, False, 0)

        chk_https = Gtk.CheckButton(label="🔒 HTTPS Enforcement (Auto-Upgrade HTTP)")
        chk_https.set_active(self.https_enabled)
        chk_https.connect("toggled", lambda cb: setattr(self, 'https_enabled', cb.get_active()))
        vbox.pack_start(chk_https, False, False, 0)

        btn_clear = Gtk.Button(label="🗑️ Clear Browsing History & Cookies")
        btn_clear.connect("clicked", self.on_clear_cache_clicked)
        vbox.pack_start(btn_clear, False, False, 4)

        about_lbl = Gtk.Label(label=f"Bharat Browser v{self.current_version} | Engineered in INDIA 🇮🇳")
        vbox.pack_start(about_lbl, False, False, 8)

        dialog.show_all()
        dialog.run()
        dialog.destroy()

    def on_clear_cache_clicked(self, btn):
        cm = self.context.get_cookie_manager()
        cm.delete_all_cookies()
        self.context.clear_cache()
        self.statusbar.push(self.context_id, "🧹 Browsing History & Cache Cleared!")

def main():
    app = BharatBrowserWindow()
    app.connect("destroy", Gtk.main_quit)
    app.show_all()
    Gtk.main()

if __name__ == "__main__":
    main()
